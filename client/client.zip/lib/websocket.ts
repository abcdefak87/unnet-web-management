// @ts-ignore - socket.io-client types will be installed
import { io, Socket } from 'socket.io-client';

class WebSocketService {
  private socket: Socket | null = null;
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 5;
  private reconnectDelay = 1000;
  private isConnecting = false;

  connect(userId: string, role: string) {
    // Prevent multiple connection attempts
    if (this.socket?.connected || this.isConnecting) {
      return this.socket;
    }

    // Cleanup existing socket if any
    if (this.socket) {
      this.socket.removeAllListeners();
      this.socket.disconnect();
      this.socket = null;
    }

    this.isConnecting = true;

    this.socket = io('http://localhost:3001', {
      transports: ['polling', 'websocket'], // Start with polling first
      timeout: 10000,
      forceNew: true,
      reconnection: false, // Handle reconnection manually
      autoConnect: true,
      upgrade: true,
      rememberUpgrade: false
    });

    this.socket.on('connect', () => {
      console.log('✅ WebSocket connected');
      this.isConnecting = false;
      this.reconnectAttempts = 0;
      
      // Join user-specific rooms
      this.socket?.emit('join-room', { userId, role });
    });

    this.socket.on('disconnect', (reason: string) => {
      console.log('❌ WebSocket disconnected:', reason);
      this.isConnecting = false;
      
      if (reason === 'io server disconnect' || reason === 'transport close') {
        // Server disconnected, try to reconnect
        this.handleReconnect(userId, role);
      }
    });

    this.socket.on('connect_error', (error: Error) => {
      console.error('WebSocket connection error:', error);
      this.isConnecting = false;
      this.handleReconnect(userId, role);
    });

    return this.socket;
  }

  private handleReconnect(userId: string, role: string) {
    if (this.reconnectAttempts < this.maxReconnectAttempts && !this.isConnecting) {
      this.reconnectAttempts++;
      console.log(`Attempting to reconnect... (${this.reconnectAttempts}/${this.maxReconnectAttempts})`);
      
      setTimeout(() => {
        if (!this.socket?.connected && !this.isConnecting) {
          this.connect(userId, role);
        }
      }, this.reconnectDelay * this.reconnectAttempts);
    }
  }

  // Job-related listeners
  onJobUpdate(callback: (data: any) => void) {
    this.socket?.on('job-update', callback);
  }

  offJobUpdate() {
    this.socket?.off('job-update');
  }

  // Inventory-related listeners
  onInventoryUpdate(callback: (data: any) => void) {
    this.socket?.on('inventory-update', callback);
  }

  offInventoryUpdate() {
    this.socket?.off('inventory-update');
  }

  // User management listeners
  onUserUpdate(callback: (data: any) => void) {
    this.socket?.on('user-update', callback);
  }

  offUserUpdate() {
    this.socket?.off('user-update');
  }

  // System notifications
  onSystemNotification(callback: (data: any) => void) {
    this.socket?.on('system-notification', callback);
  }

  offSystemNotification() {
    this.socket?.off('system-notification');
  }

  // User-specific notifications
  onUserNotification(callback: (data: any) => void) {
    this.socket?.on('user-notification', callback);
  }

  offUserNotification() {
    this.socket?.off('user-notification');
  }

  disconnect() {
    if (this.socket) {
      this.socket.removeAllListeners();
      this.socket.disconnect();
      this.socket = null;
    }
    this.isConnecting = false;
    this.reconnectAttempts = 0;
  }

  isConnected(): boolean {
    return this.socket?.connected || false;
  }
}

// Create singleton instance
const websocketService = new WebSocketService();
export default websocketService;
